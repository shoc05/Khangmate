package com.example.khangmate2.ui.screens.listing

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.repository.ListingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ListingFormViewModel @Inject constructor(
    private val repository: ListingRepository
) : ViewModel() {

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    fun addListing(
        listing: Listing,
        imageUris: List<Uri>,
        onDone: (String) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val id = repository.addListingWithImages(listing, imageUris)
                onDone(id)
            } catch (t: Throwable) {
                onError(t)
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun updateListing(
        listing: Listing,
        newImageUris: List<Uri>,
        onDone: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            try {
                repository.updateListingRemote(listing, newImageUris)
                onDone()
            } catch (t: Throwable) {
                onError(t)
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun deleteListing(
        listingId: String,
        onDone: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        viewModelScope.launch {
            try {
                repository.deleteListingRemote(listingId)
                onDone()
            } catch (t: Throwable) {
                onError(t)
            }
        }
    }
}
