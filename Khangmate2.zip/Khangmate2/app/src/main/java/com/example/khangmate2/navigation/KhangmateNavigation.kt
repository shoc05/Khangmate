package com.example.khangmate2.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.khangmate2.ui.screens.auth.LoginScreen
import com.example.khangmate2.ui.screens.auth.SignupScreen
import com.example.khangmate2.ui.screens.home.HomeScreen
import com.example.khangmate2.ui.screens.map.MapScreen
import com.example.khangmate2.ui.screens.favorites.FavoritesScreen
import com.example.khangmate2.ui.screens.chat.ChatScreen
import com.example.khangmate2.ui.screens.profile.ProfileScreen
import com.example.khangmate2.ui.screens.listing.ListingDetailScreen
import com.example.khangmate2.ui.screens.chat.ChatDetailScreen
import com.example.khangmate2.ui.screens.listing.AddListingScreen
import com.example.khangmate2.ui.screens.listing.EditListingScreen
import com.example.khangmate2.ui.screens.map.MapPickerScreen
import com.example.khangmate2.ui.screens.help.HelpSupportScreen
import com.example.khangmate2.ui.screens.about.AboutScreen
import com.example.khangmate2.ui.screens.profile.ProfileEditScreen
import com.example.khangmate2.ui.screens.profile.ChangePasswordScreen
import com.example.khangmate2.ui.screens.profile.MyListingsScreen

@Composable
fun KhangmateNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        // Auth screens
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Signup.route) {
            SignupScreen(navController = navController)
        }
        
        // Main screens
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(Screen.Map.route) {
            MapScreen(navController = navController)
        }
        composable(Screen.Favorites.route) {
            FavoritesScreen(navController = navController)
        }
        composable(Screen.Chat.route) {
            ChatScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }
        
        // Detail screens
        composable(Screen.ListingDetail.route) { backStackEntry ->
            val listingId = backStackEntry.arguments?.getString("listingId") ?: ""
            ListingDetailScreen(
                navController = navController,
                listingId = listingId
            )
        }
        composable(Screen.ChatDetail.route) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
            ChatDetailScreen(
                navController = navController,
                chatId = chatId
            )
        }
        
        // Listing management screens
        composable(Screen.AddListing.route) {
            AddListingScreen(navController = navController)
        }
        composable(Screen.EditListing.route) { backStackEntry ->
            val listingId = backStackEntry.arguments?.getString("listingId") ?: ""
            EditListingScreen(
                navController = navController,
                listingId = listingId
            )
        }
        composable("help") { HelpSupportScreen(navController) }
        composable("about") { AboutScreen(navController) }

        // Profile management
        composable("editProfile") { ProfileEditScreen(navController) }
        composable("change_password") { ChangePasswordScreen(navController) }
        composable("my_listings") { MyListingsScreen(navController) }


        // Map Picker used to select a pin and return to form
        composable("map_picker") {
            MapPickerScreen(navController = navController)
        }
    }
}
