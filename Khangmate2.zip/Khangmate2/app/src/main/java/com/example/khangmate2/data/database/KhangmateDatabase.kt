package com.example.khangmate2.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.model.Message
import com.example.khangmate2.data.model.Favorite
import com.example.khangmate2.data.model.User

@Database(
    entities = [User::class, Listing::class, Message::class, Favorite::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class KhangmateDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun messageDao(): MessageDao
    abstract fun favoriteDao(): FavoriteDao
    
    companion object {
        @Volatile
        private var INSTANCE: KhangmateDatabase? = null
        
        fun getDatabase(context: Context): KhangmateDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KhangmateDatabase::class.java,
                    "khangmate_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
