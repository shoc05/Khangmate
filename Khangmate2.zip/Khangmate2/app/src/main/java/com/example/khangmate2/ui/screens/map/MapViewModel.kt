package com.example.khangmate2.ui.screens.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.repository.ListingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MapViewModel @Inject constructor(
    private val repository: ListingRepository
) : ViewModel() {

    private val _listings = MutableStateFlow<List<Listing>>(emptyList())
    val listings: StateFlow<List<Listing>> = _listings.asStateFlow()

    private val _roomFilter = MutableStateFlow("All")
    val roomFilter: StateFlow<String> = _roomFilter.asStateFlow()

    private val _districtFilter = MutableStateFlow("")
    val districtFilter: StateFlow<String> = _districtFilter.asStateFlow()

    private val _priceRange = MutableStateFlow(0.0 to Double.MAX_VALUE)
    val priceRange: StateFlow<Pair<Double, Double>> = _priceRange.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllListings().collect { _listings.value = it }
        }
    }

    fun setRoomFilter(filter: String) {
        _roomFilter.value = filter
    }

    fun setDistrictFilter(district: String) {
        _districtFilter.value = district
    }

    fun setPriceRange(min: Double, max: Double) {
        _priceRange.value = min to max
    }

    fun filtered(): List<Listing> {
        val f = _roomFilter.value
        val district = _districtFilter.value
        val (minPrice, maxPrice) = _priceRange.value
        return _listings.value.filter { listing ->
            val roomOk = when (f) {
                "All" -> true
                "1 Room" -> listing.rooms == 1
                "2 Rooms" -> listing.rooms == 2
                "3+ Rooms" -> listing.rooms >= 3
                else -> true
            }
            val districtOk = district.isEmpty() || listing.district.equals(district, ignoreCase = true)
            val priceOk = listing.rent in minPrice..maxPrice
            roomOk && districtOk && priceOk
        }
    }
}
