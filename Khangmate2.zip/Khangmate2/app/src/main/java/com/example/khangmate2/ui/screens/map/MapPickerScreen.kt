package com.example.khangmate2.ui.screens.map

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapPickerScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    val bhutan = LatLng(27.5142, 90.4336)
    var picked by remember { mutableStateOf<LatLng?>(null) }
    val camState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(bhutan, 7.5f)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pick Location") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            )
        },
        floatingActionButton = {
            if (picked != null) {
                FloatingActionButton(onClick = {
                    navController.previousBackStackEntry?.savedStateHandle?.set("picked_lat", picked!!.latitude)
                    navController.previousBackStackEntry?.savedStateHandle?.set("picked_lng", picked!!.longitude)
                    navController.popBackStack()
                }) { Icon(Icons.Default.Check, contentDescription = "Confirm") }
            }
        },
        bottomBar = { BottomAppBar(containerColor = MaterialTheme.colorScheme.surface) {} }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = camState,
                uiSettings = MapUiSettings(zoomControlsEnabled = true),
                onMapClick = { latLng -> picked = latLng }
            ) {
                picked?.let {
                    Marker(state = MarkerState(it), title = "Selected")
                }
            }
        }
    }
}
