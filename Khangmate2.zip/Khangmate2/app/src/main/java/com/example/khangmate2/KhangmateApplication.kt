package com.example.khangmate2

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class KhangmateApplication : Application()
