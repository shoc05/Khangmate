package com.example.khangmate2.ui.screens.map

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.khangmate2.ui.components.BottomNavBar
import com.google.maps.android.compose.CameraPositionState
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.CameraPosition
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.khangmate2.R
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.content.Context
import androidx.annotation.DrawableRes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: MapViewModel = hiltViewModel()
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        val bhutan = LatLng(27.5142, 90.4336)
        var selectedListingId by remember { mutableStateOf<String?>(null) }
        var districtExpanded by remember { mutableStateOf(false) }
        val districts = listOf(
            "", "Thimphu", "Paro", "Punakha", "Wangdue Phodrang", "Haa",
            "Chhukha", "Dagana", "Tsirang", "Trongsa", "Zhemgang",
            "Bumthang", "Mongar", "Lhuentse", "Trashigang", "Trashi Yangtse",
            "Pemagatshel", "Samdrup Jongkhar", "Sarpang", "Gasa", "Samdrupcholing"
        )
        val currentDistrict by viewModel.districtFilter.collectAsState()
        val (minPrice, maxPrice) = viewModel.priceRange.collectAsState().value
        val cameraPositionState: CameraPositionState = rememberCameraPositionState {
            position = CameraPosition.fromLatLngZoom(bhutan, 7.5f)
        }

        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            uiSettings = MapUiSettings(zoomControlsEnabled = true)
        ) {
            // House markers
            val context = LocalContext.current
            val houseIcon: BitmapDescriptor = remember { bitmapDescriptorFromVector(context, R.drawable.house) }
            val houseIconSelected: BitmapDescriptor = remember { bitmapDescriptorFromVectorScaled(context, R.drawable.house, 1.35f) }
            val listings = viewModel.filtered()
            listings.forEach { listing ->
                Marker(
                    state = MarkerState(position = LatLng(listing.latitude, listing.longitude)),
                    title = listing.title,
                    snippet = "Nu. ${listing.rent.toInt()}",
                    onClick = {
                        selectedListingId = listing.id
                        navController.navigate("listing_detail/${listing.id}")
                        true
                    },
                    icon = if (selectedListingId == listing.id) houseIconSelected else houseIcon
                )
            }
        }
        // Filter chips overlay (1,2,3+ rooms)
        RoomFilterChips(
            current = viewModel.roomFilter.collectAsState().value,
            onSelect = { viewModel.setRoomFilter(it) },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(16.dp)
        )

        // District + Price filters overlay (top)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            // District dropdown
            ExposedDropdownMenuBox(expanded = districtExpanded, onExpandedChange = { districtExpanded = !districtExpanded }) {
                OutlinedTextField(
                    value = if (currentDistrict.isEmpty()) "All Districts" else currentDistrict,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("District") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = districtExpanded) },
                    modifier = Modifier.menuAnchor()
                )
                ExposedDropdownMenu(expanded = districtExpanded, onDismissRequest = { districtExpanded = false }) {
                    districts.forEach { d ->
                        DropdownMenuItem(
                            text = { Text(if (d.isEmpty()) "All" else d) },
                            onClick = {
                                viewModel.setDistrictFilter(d)
                                districtExpanded = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            // Price range slider (0 .. 200000)
            val priceRange = viewModel.priceRange.collectAsState().value
            var localRange by remember(priceRange) { mutableStateOf(priceRange.first.toFloat()..priceRange.second.toFloat()) }
            Text("Price: Nu. ${localRange.start.toInt()} - ${localRange.endInclusive.toInt()}")
            RangeSlider(
                value = localRange,
                onValueChange = { localRange = it },
                valueRange = 0f..200000f,
                onValueChangeFinished = {
                    viewModel.setPriceRange(localRange.start.toDouble(), localRange.endInclusive.toDouble())
                }
            )
        }

        // Bottom Navigation
        BottomNavBar(
            currentRoute = "map",
            onNavigate = { route ->
                when (route) {
                    "home" -> navController.navigate("home")
                    "map" -> { /* Already on map */ }
                    "favorites" -> navController.navigate("favorites")
                    "chat" -> navController.navigate("chat")
                    "profile" -> navController.navigate("profile")
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

private fun bitmapDescriptorFromVector(
    context: android.content.Context,
    @androidx.annotation.DrawableRes vectorResId: Int
): com.google.android.gms.maps.model.BitmapDescriptor {
    val drawable: android.graphics.drawable.Drawable =
        androidx.core.content.ContextCompat.getDrawable(context, vectorResId)!!
    val bitmap = android.graphics.Bitmap.createBitmap(
        drawable.intrinsicWidth.coerceAtLeast(1),
        drawable.intrinsicHeight.coerceAtLeast(1),
        android.graphics.Bitmap.Config.ARGB_8888
    )
    val canvas = android.graphics.Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return com.google.android.gms.maps.model.BitmapDescriptorFactory.fromBitmap(bitmap)
}

private fun bitmapDescriptorFromVectorScaled(
    context: android.content.Context,
    @androidx.annotation.DrawableRes vectorResId: Int,
    scale: Float
): com.google.android.gms.maps.model.BitmapDescriptor {
    val drawable: android.graphics.drawable.Drawable =
        androidx.core.content.ContextCompat.getDrawable(context, vectorResId)!!
    val baseW = drawable.intrinsicWidth.coerceAtLeast(1)
    val baseH = drawable.intrinsicHeight.coerceAtLeast(1)
    val width = (baseW * scale).toInt().coerceAtLeast(1)
    val height = (baseH * scale).toInt().coerceAtLeast(1)
    val bitmap = android.graphics.Bitmap.createBitmap(
        width,
        height,
        android.graphics.Bitmap.Config.ARGB_8888
    )
    val canvas = android.graphics.Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return com.google.android.gms.maps.model.BitmapDescriptorFactory.fromBitmap(bitmap)
}

@Composable
private fun RoomFilterChips(
    current: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val filters = listOf("All", "1 Room", "2 Rooms", "3+ Rooms")
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        filters.forEach { f ->
            AssistChip(
                onClick = { onSelect(f) },
                label = { Text(f) },
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = if (current == f) Color(0xFFEF9A9A) else Color.White
                )
            )
        }
    }
}
