package com.example.khangmate2.data.repository

import android.net.Uri
import com.example.khangmate2.data.database.ListingDao
import com.example.khangmate2.data.model.Listing
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class ListingRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val storage: FirebaseStorage,
    private val listingDao: ListingDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    fun getAllListings(): Flow<List<Listing>> = listingDao.getAllListings()
    
    fun getListingById(listingId: String): Flow<Listing?> = listingDao.getListingById(listingId)
    
    fun getListingsByDistrict(district: String): Flow<List<Listing>> = 
        listingDao.getListingsByDistrict(district)
    
    fun getListingsByPriceRange(minRent: Double, maxRent: Double): Flow<List<Listing>> = 
        listingDao.getListingsByPriceRange(minRent, maxRent)
    
    fun getListingsByRooms(rooms: Int): Flow<List<Listing>> = 
        listingDao.getListingsByRooms(rooms)
    
    suspend fun insertListing(listing: Listing) = listingDao.insertListing(listing)
    
    suspend fun updateListing(listing: Listing) = listingDao.updateListing(listing)
    
    suspend fun deleteListing(listing: Listing) = listingDao.deleteListing(listing)

    // Firestore <-> Room sync
    fun syncListings(scope: CoroutineScope) {
        firestore.collection("listings").addSnapshotListener { snapshot, _ ->
            if (snapshot == null) return@addSnapshotListener
            scope.launch(ioDispatcher) {
                // Apply changes one by one so deletes are handled
                snapshot.documentChanges.forEach { change ->
                    val doc = change.document
                    val listing = doc.toObject<Listing>().copy(id = doc.id)
                    when (change.type) {
                        DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                            listingDao.insertListing(listing)
                        }
                        DocumentChange.Type.REMOVED -> {
                            listingDao.deleteListingById(doc.id)
                        }
                    }
                }
            }
        }
    }

    // Create listing with image upload
    suspend fun addListingWithImages(
        baseListing: Listing,
        imageUris: List<Uri>
    ): String = withContext(ioDispatcher) {
        val docRef = firestore.collection("listings").document()
        val id = if (baseListing.id.isNotBlank()) baseListing.id else docRef.id

        val urls = uploadImages(id, imageUris)
        val listingToSave = baseListing.copy(id = id, imageUrls = urls)

        firestore.collection("listings").document(id).set(listingToSave).await()
        listingDao.insertListing(listingToSave)
        id
    }

    suspend fun updateListingRemote(listing: Listing, newImageUris: List<Uri>): Unit = withContext(ioDispatcher) {
        val urls = if (newImageUris.isNotEmpty()) {
            // Append new images
            val uploaded = uploadImages(listing.id, newImageUris)
            listing.imageUrls + uploaded
        } else listing.imageUrls
        val updated = listing.copy(imageUrls = urls, updatedAt = System.currentTimeMillis())
        firestore.collection("listings").document(listing.id).set(updated).await()
        listingDao.insertListing(updated)
    }

    suspend fun deleteListingRemote(listingId: String) = withContext(ioDispatcher) {
        firestore.collection("listings").document(listingId).delete().await()
        listingDao.deleteListingById(listingId)
        // Optional: delete images folder
        runCatching {
            storage.reference.child("listings/$listingId").listAll().await().items.forEach { it.delete().await() }
        }
    }

    private suspend fun uploadImages(listingId: String, uris: List<Uri>): List<String> = withContext(ioDispatcher) {
        val folder = storage.reference.child("listings/$listingId")
        uris.mapIndexed { index, uri ->
            val ref = folder.child("img_${index}_${System.currentTimeMillis()}.jpg")
            ref.putFile(uri).await()
            ref.downloadUrl.await().toString()
        }
    }
}
