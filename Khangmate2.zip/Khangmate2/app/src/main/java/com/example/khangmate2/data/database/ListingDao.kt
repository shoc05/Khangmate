package com.example.khangmate2.data.database

import androidx.room.*
import com.example.khangmate2.data.model.Listing
import kotlinx.coroutines.flow.Flow

@Dao
interface ListingDao {
    @Query("SELECT * FROM listings WHERE id = :listingId")
    fun getListingById(listingId: String): Flow<Listing?>
    
    @Query("SELECT * FROM listings ORDER BY createdAt DESC")
    fun getAllListings(): Flow<List<Listing>>
    
    @Query("SELECT * FROM listings WHERE district = :district ORDER BY createdAt DESC")
    fun getListingsByDistrict(district: String): Flow<List<Listing>>
    
    @Query("SELECT * FROM listings WHERE rent BETWEEN :minRent AND :maxRent ORDER BY createdAt DESC")
    fun getListingsByPriceRange(minRent: Double, maxRent: Double): Flow<List<Listing>>
    
    @Query("SELECT * FROM listings WHERE rooms = :rooms ORDER BY createdAt DESC")
    fun getListingsByRooms(rooms: Int): Flow<List<Listing>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: Listing)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(listings: List<Listing>)
    
    @Update
    suspend fun updateListing(listing: Listing)
    
    @Delete
    suspend fun deleteListing(listing: Listing)
    
    @Query("DELETE FROM listings WHERE id = :listingId")
    suspend fun deleteListingById(listingId: String)

    @Query("DELETE FROM listings")
    suspend fun clearAll()
}
