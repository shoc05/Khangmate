package com.example.khangmate2.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey(autoGenerate = true) val localId: Long = 0,
    val userId: String,
    val listingId: String,
    val createdAt: Long = System.currentTimeMillis()
)
