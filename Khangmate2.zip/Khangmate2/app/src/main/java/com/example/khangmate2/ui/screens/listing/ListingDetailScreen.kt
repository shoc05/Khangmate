package com.example.khangmate2.ui.screens.listing

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.ui.theme.BhutanGreen
import com.example.khangmate2.ui.theme.BhutanRed
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListingDetailScreen(
    navController: NavController,
    listingId: String,
    modifier: Modifier = Modifier,
    viewModel: ListingDetailViewModel = hiltViewModel()
) {
    LaunchedEffect(listingId) { viewModel.load(listingId) }
    val listing by viewModel.listing.collectAsState()
    val favVm: com.example.khangmate2.ui.viewmodel.FavoritesViewModel = hiltViewModel()
    val favoriteIds by favVm.favoriteIds.collectAsState()
    val isFavorite = listing?.id?.let { favoriteIds.contains(it) } ?: false
    val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
    val isOwner = listing?.ownerId == currentUser?.uid
    val formVm: ListingFormViewModel = hiltViewModel()
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Top bar
        TopAppBar(
            title = { Text("Property Details") },
            navigationIcon = {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            confirmButton = {
                TextButton(onClick = {
                    val id = listing?.id ?: return@TextButton
                    formVm.deleteListing(
                        listingId = id,
                        onDone = {
                            showDeleteConfirm = false
                            navController.popBackStack()
                        },
                        onError = { showDeleteConfirm = false }
                    )
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            },
            title = { Text("Delete Listing") },
            text = { Text("Are you sure you want to delete this listing? This action cannot be undone.") }
        )
    }
            },
            actions = {
                IconButton(onClick = { /* Share */ }) {
                    Icon(Icons.Default.Share, contentDescription = "Share")
                }
                IconButton(onClick = { listing?.id?.let { favVm.toggleFavorite(it) } }) {
                    if (isFavorite) {
                        Icon(Icons.Default.Favorite, contentDescription = "Unfavorite", tint = BhutanRed)
                    } else {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = "Favorite")
                    }
                }
                if (isOwner) {
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White,
                titleContentColor = Color.Black
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Image carousel
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val images = listing?.imageUrls?.ifEmpty { listOf("https://via.placeholder.com/300") } ?: listOf()
                items(images) { imageUrl ->
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = "Property image",
                        modifier = Modifier
                            .width(300.dp)
                            .height(250.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Title, address, and rent
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = listing?.title ?: "",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = listOf(listing?.district ?: "", listing?.address ?: "")
                            .filter { it.isNotBlank() }
                            .joinToString(", "),
                        fontSize = 16.sp,
                        color = Color.Gray
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = BhutanRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Nu. ${listing?.rent?.toInt() ?: 0}/month",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Availability and Contact
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BhutanGreen),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Available Now",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                Button(
                    onClick = { /* Contact owner */ },
                    colors = ButtonDefaults.buttonColors(containerColor = BhutanRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = "Contact", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Contact Owner")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Property Details
            Text("Property Details", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(Modifier.height(12.dp))
            PropertyDetailItem(Icons.Default.MeetingRoom, "Rooms", "${listing?.rooms ?: 0} Bedrooms")
            PropertyDetailItem(Icons.Default.LocationOn, "Location", listing?.district ?: "")
            PropertyDetailItem(Icons.Default.Home, "Type", "Apartment")

            Spacer(modifier = Modifier.height(24.dp))

            // Description
            Text("Description", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = listing?.description ?: "",
                fontSize = 16.sp,
                color = Color.Gray,
                lineHeight = 24.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Amenities
            Text("Amenities", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listing?.amenities ?: emptyList()) { amenity ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = amenity,
                            color = Color.Black,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Map preview
            val lat = listing?.latitude ?: 27.5142
            val lng = listing?.longitude ?: 90.4336
            val center = LatLng(lat, lng)
            val camState = rememberCameraPositionState {
                position = CameraPosition.fromLatLngZoom(center, 14f)
            }

            Text("Location", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                GoogleMap(
                    modifier = Modifier.fillMaxSize(),
                    cameraPositionState = camState,
                    uiSettings = com.google.maps.android.compose.MapUiSettings(zoomControlsEnabled = false)
                ) {
                    Marker(state = MarkerState(center), title = listing?.title ?: "")
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }

        // Bottom action bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { listing?.id?.let { favVm.toggleFavorite(it) } },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BhutanRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    val icon = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder
                    Icon(icon, contentDescription = "Favorite", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (isFavorite) "Saved" else "Save")
                }

                Button(
                    onClick = { /* Contact owner */ },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = BhutanRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = "Contact", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Contact")
                }
            }
        }
    }
}

@Composable
private fun PropertyDetailItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = Color.Gray, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 16.sp, color = Color.Gray, modifier = Modifier.width(80.dp))
        Text(value, fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.Medium)
    }
}
