package com.example.khangmate2.ui.screens.listing

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.khangmate2.ui.theme.BhutanRed
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.rememberAsyncImagePainter
import com.example.khangmate2.data.model.Listing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditListingScreen(
    navController: NavController,
    listingId: String,
    modifier: Modifier = Modifier,
    detailViewModel: ListingDetailViewModel = hiltViewModel(),
    formViewModel: ListingFormViewModel = hiltViewModel()
) {
    LaunchedEffect(listingId) { detailViewModel.load(listingId) }
    val existing by detailViewModel.listing.collectAsState()

    var title by remember { mutableStateOf(existing?.title ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var rent by remember { mutableStateOf(existing?.rent?.toInt()?.toString() ?: "") }
    var selectedDistrict by remember { mutableStateOf(existing?.district ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var rooms by remember { mutableStateOf(existing?.rooms?.toString() ?: "") }
    var latitude by remember { mutableStateOf(existing?.latitude ?: 27.5142) }
    var longitude by remember { mutableStateOf(existing?.longitude ?: 90.4336) }

    // New photo selection
    var newPhotoUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris != null) newPhotoUris = uris
    }

    // Receive map pick result
    val saved = navController.currentBackStackEntry?.savedStateHandle
    val pickedLat by saved?.getStateFlow("picked_lat", latitude)?.collectAsState(initial = latitude)!!
    val pickedLng by saved?.getStateFlow("picked_lng", longitude)?.collectAsState(initial = longitude)!!
    LaunchedEffect(pickedLat, pickedLng) {
        latitude = pickedLat
        longitude = pickedLng
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Top bar
        TopAppBar(
            title = { Text("Edit Listing") },
            navigationIcon = {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White,
                titleContentColor = Color.Black
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Title field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Property Title") },
                placeholder = { Text("Enter property title") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Description field
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("Describe your property") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Rent field
            OutlinedTextField(
                value = rent,
                onValueChange = { rent = it },
                label = { Text("Monthly Rent (Nu.)") },
                placeholder = { Text("Enter monthly rent") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // District dropdown
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = selectedDistrict,
                    onValueChange = { },
                    readOnly = true,
                    label = { Text("District (Dzongkhag)") },
                    placeholder = { Text("Select district") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BhutanRed,
                        focusedLabelColor = BhutanRed
                    )
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    listOf("Thimphu", "Paro", "Punakha", "Bumthang", "Trashigang").forEach { district ->
                        DropdownMenuItem(
                            text = { Text(district) },
                            onClick = {
                                selectedDistrict = district
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Address field
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                placeholder = { Text("Enter full address") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Rooms field
            OutlinedTextField(
                value = rooms,
                onValueChange = { rooms = it },
                label = { Text("Number of Rooms") },
                placeholder = { Text("Enter number of rooms") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Update photos section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { photoPicker.launch("image/*") },
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "📷", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Update Photos", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(
                        text = if (newPhotoUris.isEmpty()) "Tap to add more photos" else "Selected ${newPhotoUris.size} new photos",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Map pick button
            OutlinedButton(
                onClick = { navController.navigate("map_picker") },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BhutanRed)
            ) {
                Text("Update Location (lat: ${"%.4f".format(latitude)}, lng: ${"%.4f".format(longitude)})")
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Update button
            Button(
                onClick = {
                    existing?.let {
                        val updated = it.copy(
                            title = title,
                            description = description,
                            rent = rent.toDoubleOrNull() ?: 0.0,
                            district = selectedDistrict,
                            address = address,
                            rooms = rooms.toIntOrNull() ?: 0,
                            latitude = latitude,
                            longitude = longitude,
                            updatedAt = System.currentTimeMillis()
                        )
                        formViewModel.updateListing(updated, newPhotoUris, onDone = {
                            navController.popBackStack()
                        }, onError = { })
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BhutanRed),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Update Listing",
                    color = androidx.compose.ui.graphics.Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Delete button
            OutlinedButton(
                onClick = { formViewModel.deleteListing(listingId, onDone = { navController.popBackStack() }, onError = { }) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = androidx.compose.ui.graphics.Color.Red),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Delete Listing",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
