package com.example.khangmate2.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.repository.ListingRepository
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyListingsViewModel @Inject constructor(
    private val listingRepository: ListingRepository,
    private val auth: FirebaseAuth
) : ViewModel() {

    private val _items = MutableStateFlow<List<Listing>>(emptyList())
    val items: StateFlow<List<Listing>> = _items.asStateFlow()

    init {
        viewModelScope.launch {
            listingRepository.getAllListings().collectLatest { all ->
                val uid = auth.currentUser?.uid
                _items.value = if (uid == null) emptyList() else all.filter { it.ownerId == uid }
            }
        }
    }
}
