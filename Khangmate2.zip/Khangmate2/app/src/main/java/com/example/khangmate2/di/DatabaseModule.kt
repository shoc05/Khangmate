package com.example.khangmate2.di

import android.content.Context
import androidx.room.Room
import com.example.khangmate2.data.database.KhangmateDatabase
import com.example.khangmate2.data.database.ListingDao
import com.example.khangmate2.data.database.MessageDao
import com.example.khangmate2.data.database.UserDao
import com.example.khangmate2.data.database.FavoriteDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideKhangmateDatabase(@ApplicationContext context: Context): KhangmateDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            KhangmateDatabase::class.java,
            "khangmate_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }
    
    @Provides
    fun provideUserDao(database: KhangmateDatabase): UserDao = database.userDao()
    
    @Provides
    fun provideListingDao(database: KhangmateDatabase): ListingDao = database.listingDao()
    
    @Provides
    fun provideMessageDao(database: KhangmateDatabase): MessageDao = database.messageDao()

    @Provides
    fun provideFavoriteDao(database: KhangmateDatabase): FavoriteDao = database.favoriteDao()
}
