package com.example.khangmate2.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.repository.FavoritesRepository
import com.example.khangmate2.data.repository.ListingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val favoritesRepository: FavoritesRepository,
    private val listingRepository: ListingRepository
) : ViewModel() {

    private val _favoriteIds = MutableStateFlow<Set<String>>(emptySet())
    val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

    private val _favoriteListings = MutableStateFlow<List<Listing>>(emptyList())
    val favoriteListings: StateFlow<List<Listing>> = _favoriteListings.asStateFlow()

    init {
        viewModelScope.launch {
            favoritesRepository.favoriteIdsFlow().collectLatest { ids ->
                _favoriteIds.value = ids
                // keep Room cache aligned (optional)
                favoritesRepository.syncLocalFromIds(ids)
            }
        }

        viewModelScope.launch {
            listingRepository.getAllListings().collectLatest { all ->
                val ids = _favoriteIds.value
                _favoriteListings.value = all.filter { ids.contains(it.id) }
            }
        }
    }

    fun isFavorite(id: String): Boolean = _favoriteIds.value.contains(id)

    fun toggleFavorite(listingId: String) {
        viewModelScope.launch {
            favoritesRepository.toggleFavorite(listingId)
        }
    }
}
