package com.example.khangmate2.data.repository

import com.example.khangmate2.data.database.FavoriteDao
import com.example.khangmate2.data.model.Favorite
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FavoritesRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val favoriteDao: FavoriteDao,
    private val auth: FirebaseAuth,
    private val ioDispatcher: CoroutineDispatcher
) {
    private fun userId(): String? = auth.currentUser?.uid

    fun favoriteIdsFlow(): Flow<Set<String>> {
        val uid = userId() ?: return favoriteDao.getFavoriteIdsForUser("").map { emptySet() }
        return remoteFavoriteIds(uid)
    }

    fun favoritesForUser(): Flow<List<Favorite>> {
        val uid = userId() ?: return favoriteDao.getFavoritesForUser("")
        return favoriteDao.getFavoritesForUser(uid)
    }

    suspend fun syncLocalFromIds(ids: Set<String>) = withContext(ioDispatcher) {
        val uid = userId() ?: return@withContext
        favoriteDao.clearForUser(uid)
        ids.forEach { id -> favoriteDao.insertFavorite(Favorite(userId = uid, listingId = id)) }
    }

    fun remoteFavoriteIds(uid: String): Flow<Set<String>> = callbackFlow {
        val ref = firestore.collection("users").document(uid).collection("favorites")
        val reg = ref.addSnapshotListener { snap, _ ->
            if (snap != null) {
                val ids = snap.documents.mapNotNull { it.id }.toSet()
                trySend(ids)
            }
        }
        awaitClose { reg.remove() }
    }

    suspend fun toggleFavorite(listingId: String) = withContext(ioDispatcher) {
        val uid = userId() ?: return@withContext
        val current = favoriteDao.getFavoriteIdsForUser(uid).first().toSet()
        val ref = firestore.collection("users").document(uid).collection("favorites").document(listingId)
        if (current.contains(listingId)) {
            // remove
            ref.delete().await()
            favoriteDao.deleteFavorite(uid, listingId)
        } else {
            // add
            ref.set(mapOf("createdAt" to System.currentTimeMillis())).await()
            favoriteDao.insertFavorite(Favorite(userId = uid, listingId = listingId))
        }
    }
}
