package com.example.khangmate2.ui.theme

import androidx.compose.ui.graphics.Color

// Red Bhutanese Identity Theme
val Red80 = Color(0xFFD32F2F) // Primary red
val RedGrey80 = Color(0xFFB71C1C) // Darker red
val RedLight80 = Color(0xFFFFCDD2) // Light red

val Red40 = Color(0xFF8B0000) // Maroon red
val RedGrey40 = Color(0xFF5D0000) // Dark maroon
val RedLight40 = Color(0xFFE57373) // Medium red

// Additional colors for the app
val BhutanRed = Color(0xFFD32F2F) // Main Bhutanese red
val BhutanMaroon = Color(0xFF8B0000) // Dark maroon
val BhutanGold = Color(0xFFFFD700) // Gold accent
val BhutanGreen = Color(0xFF4CAF50) // Success green
val BhutanBlue = Color(0xFF2196F3) // Info blue

// Neutral colors
val DarkGray = Color(0xFF424242)
val MediumGray = Color(0xFF757575)
val LightGray = Color(0xFFBDBDBD)
val BackgroundGray = Color(0xFFF5F5F5)