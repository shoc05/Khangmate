package com.example.khangmate2.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.khangmate2.data.model.Listing
import com.example.khangmate2.data.repository.ListingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val listingRepository: ListingRepository
) : ViewModel() {
    
    private val _listings = MutableStateFlow<List<Listing>>(emptyList())
    val listings: StateFlow<List<Listing>> = _listings.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _selectedFilter = MutableStateFlow("All")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()
    
    private val _selectedDistrict = MutableStateFlow("")
    val selectedDistrict: StateFlow<String> = _selectedDistrict.asStateFlow()

    private val _priceRange = MutableStateFlow(0.0 to Double.MAX_VALUE)
    val priceRange: StateFlow<Pair<Double, Double>> = _priceRange.asStateFlow()

    init {
        // Start Firestore -> Room sync
        listingRepository.syncListings(viewModelScope)
        loadListings()
    }
    
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        filterListings()
    }
    
    fun updateSelectedFilter(filter: String) {
        _selectedFilter.value = filter
        filterListings()
    }

    fun updateDistrictFilter(district: String) {
        _selectedDistrict.value = district
        filterListings()
    }

    fun updatePriceRange(min: Double, max: Double) {
        _priceRange.value = min to max
        filterListings()
    }
    
    private fun loadListings() {
        viewModelScope.launch {
            _isLoading.value = true
            listingRepository.getAllListings().collect { listings ->
                _listings.value = listings
                _isLoading.value = false
            }
        }
    }
    
    private fun filterListings() {
        // Filtering based on search query, room chips, district and price range
        viewModelScope.launch {
            listingRepository.getAllListings().collect { allListings ->
                val filtered = allListings.filter { listing ->
                    val matchesSearch = _searchQuery.value.isEmpty() || 
                        listing.title.contains(_searchQuery.value, ignoreCase = true) ||
                        listing.district.contains(_searchQuery.value, ignoreCase = true)
                    
                    val matchesFilter = when (_selectedFilter.value) {
                        "All" -> true
                        "1 Room" -> listing.rooms == 1
                        "2 Rooms" -> listing.rooms == 2
                        "3+ Rooms" -> listing.rooms >= 3
                        else -> true
                    }

                    val matchesDistrict = _selectedDistrict.value.isEmpty() ||
                        listing.district.equals(_selectedDistrict.value, ignoreCase = true)

                    val (minP, maxP) = _priceRange.value
                    val matchesPrice = listing.rent in minP..maxP
                    
                    matchesSearch && matchesFilter && matchesDistrict && matchesPrice
                }
                _listings.value = filtered
            }
        }
    }
}
