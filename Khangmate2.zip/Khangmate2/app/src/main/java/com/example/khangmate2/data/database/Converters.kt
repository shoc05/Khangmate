package com.example.khangmate2.data.database

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromStringList(list: List<String>?): String = list?.joinToString(separator = "|||") ?: ""

    @TypeConverter
    fun toStringList(data: String?): List<String> =
        if (data.isNullOrEmpty()) emptyList() else data.split("|||")
}


