package com.example.khangmate2.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.khangmate2.ui.components.ListingCard
import com.example.khangmate2.ui.theme.BhutanRed
import com.example.khangmate2.ui.screens.listing.ListingFormViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListingsScreen(navController: NavController) {
    val vm: MyListingsViewModel = hiltViewModel()
    val items by vm.items.collectAsState()
    val formVm: ListingFormViewModel = hiltViewModel()
    var toDeleteId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Listings") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(Color.White).padding(padding)) {
            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("You have not posted any listings yet")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(8.dp)
                ) {
                    items(items) { listing ->
                        ListingCard(
                            listing = listing,
                            onCardClick = { navController.navigate("listing_detail/${listing.id}") },
                            onViewDetailsClick = { navController.navigate("listing_detail/${listing.id}") }
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { navController.navigate("edit_listing/${listing.id}") }) {
                                Text("Edit", color = BhutanRed)
                            }
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = { toDeleteId = listing.id }) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red)
                                Spacer(Modifier.width(4.dp))
                                Text("Delete", color = Color.Red)
                            }
                        }
                    }
                }
            }
        }
    }

    if (toDeleteId != null) {
        AlertDialog(
            onDismissRequest = { toDeleteId = null },
            confirmButton = {
                TextButton(onClick = {
                    val id = toDeleteId ?: return@TextButton
                    formVm.deleteListing(
                        listingId = id,
                        onDone = {
                            toDeleteId = null
                            navController.popBackStack()
                        },
                        onError = { toDeleteId = null }
                    )
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDeleteId = null }) { Text("Cancel") } },
            title = { Text("Delete Listing") },
            text = { Text("Are you sure you want to delete this listing?") }
        )
    }
}
