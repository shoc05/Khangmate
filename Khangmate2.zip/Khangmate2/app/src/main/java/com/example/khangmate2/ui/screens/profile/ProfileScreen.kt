package com.example.khangmate2.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.khangmate2.data.database.KhangmateDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import com.example.khangmate2.ui.components.BottomNavBar
import com.example.khangmate2.ui.theme.BhutanRed
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class User(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val district: String = "",
    val profileImage: String = ""
)

@Composable
fun ProfileScreen(navController: NavController) {
    var user by remember { mutableStateOf(User()) }
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val userId = auth.currentUser?.uid
        userId?.let {
            db.collection("users").document(it).get()
                .addOnSuccessListener { doc ->
                    doc?.toObject(User::class.java)?.let { fetched ->
                        user = fetched
                    }
                }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        ) {
            // Header
            Text(
                text = "Profile",
                fontSize = 24.sp,
                color = Color.Black,
                modifier = Modifier.padding(16.dp)
            )

            // Profile Card
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (user.profileImage.isNotEmpty()) {
                        AsyncImage(
                            model = user.profileImage,
                            contentDescription = "Profile Image",
                            modifier = Modifier.size(100.dp).clip(CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier.size(100.dp).clip(CircleShape).background(BhutanRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user.name.take(2).uppercase(),
                                color = Color.White,
                                fontSize = 32.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Text(user.name, fontSize = 20.sp, color = Color.Black)
                    Text(user.phone, fontSize = 14.sp, color = Color.Gray)
                    Text(user.district, fontSize = 14.sp, color = Color.Gray)
                }
            }

            // Menu Items
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column {
                    ProfileMenuItem(Icons.Default.Edit, "Edit Profile") {
                        navController.navigate("editProfile")
                    }
                    ProfileMenuItem(Icons.Default.Home, "My Listings") {
                        navController.navigate("my_listings")
                    }
                    ProfileMenuItem(Icons.Default.Favorite, "Favorites") {
                        navController.navigate("favorites")
                    }
                    ProfileMenuItem(Icons.Default.Chat, "Messages") {
                        navController.navigate("chat")
                    }
                    ProfileMenuItem(Icons.Default.Settings, "Settings") {}
                    ProfileMenuItem(Icons.Default.Lock, "Change Password") {
                        navController.navigate("change_password")
                    }
                    ProfileMenuItem(Icons.Default.Help, "Help & Support") {
                        navController.navigate("help")
                    }
                    ProfileMenuItem(Icons.Default.Info, "About") {
                        navController.navigate("about")
                    }
                }
            }

            // Sign out
            Button(
                onClick = {
                    scope.launch {
                        auth.signOut()
                        withContext(Dispatchers.IO) {
                            KhangmateDatabase.getDatabase(context).clearAllTables()
                        }
                        navController.navigate("login") {
                            popUpTo("home") { inclusive = true }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Sign Out")
            }

            Spacer(Modifier.height(100.dp))
        }

        BottomNavBar(currentRoute = "profile", onNavigate = { route ->
            navController.navigate(route)
        }, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun ProfileMenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = title, tint = Color.Gray, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(16.dp))
        Text(title, fontSize = 16.sp, color = Color.Black)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
}
