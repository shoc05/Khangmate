package com.example.khangmate2.ui.screens.listing

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.khangmate2.ui.theme.BhutanRed
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.khangmate2.data.model.Listing
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddListingScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: ListingFormViewModel = hiltViewModel()
) {
    // Auth guard: redirect to login if not signed in
    val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
    LaunchedEffect(currentUser) {
        if (currentUser == null) navController.navigate("login")
    }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var rent by remember { mutableStateOf("") }
    var selectedDistrict by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var rooms by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf(27.5142) }
    var longitude by remember { mutableStateOf(90.4336) }

    // For dropdown
    var expanded by remember { mutableStateOf(false) }

    // For photo upload
    var photoUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris != null) photoUris = uris
    }

    // Receive picked lat/lng from MapPicker
    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val pickedLat by savedStateHandle?.getStateFlow("picked_lat", latitude)?.collectAsState(initial = latitude)!!
    val pickedLng by savedStateHandle?.getStateFlow("picked_lng", longitude)?.collectAsState(initial = longitude)!!
    LaunchedEffect(pickedLat, pickedLng) {
        latitude = pickedLat
        longitude = pickedLng
    }

    var showSuccess by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        // Title
        OutlinedTextField(
            value = title,
            onValueChange = { if (it.length <= 60) title = it },
            label = { Text("Property Title") },
            placeholder = { Text("Enter property title") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            supportingText = { Text("${title.length}/60") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BhutanRed,
                focusedLabelColor = BhutanRed
            )
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Description
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") },
            placeholder = { Text("Describe your property") },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BhutanRed,
                focusedLabelColor = BhutanRed
            )
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Rent
        OutlinedTextField(
            value = rent,
            onValueChange = { rent = it },
            label = { Text("Monthly Rent (Nu.)") },
            placeholder = { Text("Enter monthly rent") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BhutanRed,
                focusedLabelColor = BhutanRed
            )
        )
        Spacer(modifier = Modifier.height(16.dp))

        // District dropdown
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                value = selectedDistrict,
                onValueChange = {},
                readOnly = true,
                label = { Text("District (Dzongkhag)") },
                placeholder = { Text("Select district") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhutanRed,
                    focusedLabelColor = BhutanRed
                )
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                listOf(
                    "Thimphu", "Paro", "Punakha", "Wangdue Phodrang", "Haa",
                    "Chhukha", "Dagana", "Tsirang", "Trongsa", "Zhemgang",
                    "Bumthang", "Mongar", "Lhuentse", "Trashigang", "Trashi Yangtse",
                    "Pemagatshel", "Samdrup Jongkhar", "Sarpang", "Gasa", "Samdrupcholing"
                ).forEach { district ->
                    DropdownMenuItem(
                        text = { Text(district) },
                        onClick = {
                            selectedDistrict = district
                            expanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Address
        OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("Address") },
            placeholder = { Text("Enter full address") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BhutanRed,
                focusedLabelColor = BhutanRed
            )
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Rooms
        OutlinedTextField(
            value = rooms,
            onValueChange = { rooms = it },
            label = { Text("Number of Rooms") },
            placeholder = { Text("Enter number of rooms") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BhutanRed,
                focusedLabelColor = BhutanRed
            )
        )
        Spacer(modifier = Modifier.height(32.dp))

        // Add photos (multiple)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { launcher.launch("image/*") },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (photoUris.isEmpty()) {
                    Text("📷", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Add Photos", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("Tap to add property photos", fontSize = 14.sp, color = Color.Gray)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        photoUris.forEach { uri ->
                            Image(
                                painter = rememberAsyncImagePainter(uri),
                                contentDescription = "Selected Photo",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .background(Color.LightGray),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Pick location on map
        OutlinedButton(
            onClick = { navController.navigate("map_picker") },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BhutanRed)
        ) {
            Text(text = "Pick Location on Map (lat: ${"%.4f".format(latitude)}, lng: ${"%.4f".format(longitude)})")
        }

        // Buttons row (Cancel + Submit)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BhutanRed)
            ) {
                Text("Cancel")
            }

            Button(
                onClick = { showConfirm = true },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BhutanRed),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Add Listing", color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    if (showSuccess) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSuccess = false },
            confirmButton = {
                TextButton(onClick = {
                    showSuccess = false
                    navController.popBackStack()
                }) { Text("OK") }
            },
            title = { Text("Listing Uploaded") },
            text = { Text("Your listing was uploaded successfully.") }
        )
    }

    if (showConfirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showConfirm = false },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    val newListing = Listing(
                        id = UUID.randomUUID().toString(),
                        title = title,
                        description = description,
                        rent = rent.toDoubleOrNull() ?: 0.0,
                        district = selectedDistrict,
                        address = address,
                        rooms = rooms.toIntOrNull() ?: 0,
                        amenities = emptyList(),
                        imageUrls = emptyList(),
                        ownerId = currentUser?.uid ?: "",
                        latitude = latitude,
                        longitude = longitude
                    )
                    viewModel.addListing(newListing, photoUris, onDone = {
                        showSuccess = true
                    }, onError = { /* TODO show error: could show Snackbar */ })
                }) { Text("Confirm") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("Cancel") }
            },
            title = { Text("Confirm Submission") },
            text = { Text("Are you sure you want to add this listing?") }
        )
    }
}
