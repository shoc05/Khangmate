package com.example.khangmate2.data.database

import androidx.room.*
import com.example.khangmate2.data.model.Favorite
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites WHERE userId = :userId ORDER BY createdAt DESC")
    fun getFavoritesForUser(userId: String): Flow<List<Favorite>>

    @Query("SELECT listingId FROM favorites WHERE userId = :userId")
    fun getFavoriteIdsForUser(userId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: Favorite)

    @Query("DELETE FROM favorites WHERE userId = :userId AND listingId = :listingId")
    suspend fun deleteFavorite(userId: String, listingId: String)

    @Query("DELETE FROM favorites WHERE userId = :userId")
    suspend fun clearForUser(userId: String)
}
