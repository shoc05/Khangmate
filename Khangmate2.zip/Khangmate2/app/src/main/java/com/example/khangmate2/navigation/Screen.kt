package com.example.khangmate2.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Signup : Screen("signup")
    object Home : Screen("home")
    object Map : Screen("map")
    object Favorites : Screen("favorites")
    object Chat : Screen("chat")
    object Profile : Screen("profile")
    object ListingDetail : Screen("listing_detail/{listingId}") {
        fun createRoute(listingId: String) = "listing_detail/$listingId"
    }
    object ChatDetail : Screen("chat_detail/{chatId}") {
        fun createRoute(chatId: String) = "chat_detail/$chatId"
    }
    object AddListing : Screen("add_listing")
    object EditListing : Screen("edit_listing/{listingId}") {
        fun createRoute(listingId: String) = "edit_listing/$listingId"
    }
}
