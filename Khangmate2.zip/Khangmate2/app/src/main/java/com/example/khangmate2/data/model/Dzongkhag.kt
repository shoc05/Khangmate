package com.example.khangmate2.data.model

data class Dzongkhag(
    val id: String,
    val name: String,
    val nameDzongkha: String, // Dzongkha name
    val latitude: Double,
    val longitude: Double
)

// 20 Bhutanese Dzongkhags
val BHUTAN_DZONGKHAGS = listOf(
    Dzongkhag("1", "Bumthang", "བུམ་ཐང་", 27.5167, 90.8167),
    Dzongkhag("2", "Chhukha", "ཆུ་ཁ་", 26.8500, 89.3833),
    Dzongkhag("3", "Dagana", "དར་དཀར་ན་", 27.0667, 89.8833),
    Dzongkhag("4", "Gasa", "མགར་ས་", 28.0833, 89.4167),
    Dzongkhag("5", "Haa", "ཧཱ་", 27.3667, 89.2833),
    Dzongkhag("6", "Lhuntse", "ལྷུན་རྩེ་", 27.6667, 91.1833),
    Dzongkhag("7", "Mongar", "མོང་སྒར་", 27.2500, 91.2000),
    Dzongkhag("8", "Paro", "སྤ་རོ་", 27.4333, 89.4167),
    Dzongkhag("9", "Pemagatshel", "པད་མ་དགའ་ཚལ་", 26.9167, 91.4167),
    Dzongkhag("10", "Punakha", "སྤུ་ན་ཁ་", 27.6167, 89.8667),
    Dzongkhag("11", "Samdrup Jongkhar", "བསམ་གྲུབ་ལྗོངས་མཁར་", 26.8000, 91.5000),
    Dzongkhag("12", "Samtse", "བསམ་རྩེ་", 26.9000, 89.1000),
    Dzongkhag("13", "Sarpang", "གསར་སྤང་", 26.8667, 90.2667),
    Dzongkhag("14", "Thimphu", "ཐིམ་ཕུ་", 27.4667, 89.6333),
    Dzongkhag("15", "Trashigang", "བཀྲ་ཤིས་སྒང་", 27.3333, 91.5500),
    Dzongkhag("16", "Trashiyangtse", "བཀྲ་ཤིས་གཡང་རྩེ་", 27.6000, 91.5000),
    Dzongkhag("17", "Trongsa", "ཀྲོང་གསར་", 27.5167, 90.5000),
    Dzongkhag("18", "Tsirang", "རྩི་རང་", 26.9167, 90.1000),
    Dzongkhag("19", "Wangdue Phodrang", "དབང་འདུས་ཕོ་བྲང་", 27.4833, 90.1000),
    Dzongkhag("20", "Zhemgang", "གཞལ་སྒང་", 27.2000, 90.7333)
)
