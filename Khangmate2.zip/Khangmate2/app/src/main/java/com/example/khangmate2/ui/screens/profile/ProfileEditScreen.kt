package com.example.khangmate2.ui.screens.profile

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.khangmate2.ui.theme.BhutanRed
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditScreen(navController: NavController) {
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val storage = FirebaseStorage.getInstance()

    val userId = auth.currentUser?.uid ?: ""
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var profileImage by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }

    // Pick image
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? -> imageUri = uri }

    // Load user data
    LaunchedEffect(Unit) {
        if (userId.isNotEmpty()) {
            val snapshot = db.collection("users").document(userId).get().await()
            snapshot?.let {
                name = it.getString("name") ?: ""
                phone = it.getString("phone") ?: ""
                district = it.getString("district") ?: ""
                profileImage = it.getString("profileImage") ?: ""
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Profile") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile image
            Box(
                modifier = Modifier.size(120.dp).clip(CircleShape).background(BhutanRed).clickable {
                    launcher.launch("image/*")
                },
                contentAlignment = Alignment.Center
            ) {
                when {
                    imageUri != null -> Image(
                        painter = rememberAsyncImagePainter(imageUri),
                        contentDescription = "Selected",
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                    profileImage.isNotEmpty() -> Image(
                        painter = rememberAsyncImagePainter(profileImage),
                        contentDescription = "Profile",
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                    else -> Text("Add", color = Color.White)
                }
            }

            Spacer(Modifier.height(20.dp))

            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("District") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    if (userId.isNotEmpty()) {
                        // Upload image if selected
                        if (imageUri != null) {
                            val ref = storage.reference.child("profileImages/$userId.jpg")
                            ref.putFile(imageUri!!)
                                .addOnSuccessListener {
                                    ref.downloadUrl.addOnSuccessListener { downloadUrl ->
                                        profileImage = downloadUrl.toString()
                                        saveUser(db, userId, name, phone, district, profileImage, context, navController)
                                    }
                                }
                        } else {
                            saveUser(db, userId, name, phone, district, profileImage, context, navController)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BhutanRed)
            ) {
                Text("Save", color = Color.White)
            }
        }
    }
}

private fun saveUser(
    db: FirebaseFirestore,
    userId: String,
    name: String,
    phone: String,
    district: String,
    profileImage: String,
    context: android.content.Context,
    navController: NavController
) {
    val update = mapOf(
        "name" to name,
        "phone" to phone,
        "district" to district,
        "profileImage" to profileImage
    )
    db.collection("users").document(userId).update(update)
        .addOnSuccessListener {
            Toast.makeText(context, "Profile updated", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }
        .addOnFailureListener {
            Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show()
        }
}
