package com.example.khangmate2.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.khangmate2.ui.theme.BhutanRed
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangePasswordScreen(navController: NavController) {
    val auth = remember { FirebaseAuth.getInstance() }
    var current by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Password") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = current,
                onValueChange = { current = it },
                label = { Text("Current Password") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = newPass,
                onValueChange = { newPass = it },
                label = { Text("New Password") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it },
                label = { Text("Confirm New Password") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation()
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val user = auth.currentUser
                    if (user == null) {
                        message = "Not signed in"
                        return@Button
                    }
                    if (newPass.isBlank() || newPass != confirm) {
                        message = "Passwords do not match"
                        return@Button
                    }
                    val email = user.email
                    if (email.isNullOrBlank()) {
                        message = "Email auth required"
                        return@Button
                    }
                    isLoading = true
                    val cred = EmailAuthProvider.getCredential(email, current)
                    user.reauthenticate(cred).addOnCompleteListener { rea ->
                        if (rea.isSuccessful) {
                            user.updatePassword(newPass).addOnCompleteListener { upd ->
                                isLoading = false
                                if (upd.isSuccessful) {
                                    message = "Password updated"
                                    navController.popBackStack()
                                } else {
                                    message = upd.exception?.localizedMessage
                                }
                            }
                        } else {
                            isLoading = false
                            message = rea.exception?.localizedMessage
                        }
                    }
                },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = BhutanRed),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (isLoading) "Updating..." else "Update Password") }

            if (message != null) {
                Spacer(Modifier.height(12.dp))
                Text(message ?: "", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
