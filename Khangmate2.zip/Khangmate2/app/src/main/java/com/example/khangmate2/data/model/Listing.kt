package com.example.khangmate2.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val rent: Double = 0.0, // In Ngultrum (Nu.)
    val district: String = "", // Dzongkhag
    val address: String = "",
    val rooms: Int = 0,
    val amenities: List<String> = emptyList(),
    val imageUrls: List<String> = emptyList(),
    val ownerId: String = "",
    val latitude: Double = 27.5142,
    val longitude: Double = 90.4336,
    val isAvailable: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
