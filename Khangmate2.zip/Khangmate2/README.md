# Khangmate - Bhutanese Rental Property App

A modern Android app built with Jetpack Compose for Bhutanese users to list and browse rental properties.

## Features

- **Authentication**: Phone number OTP verification with Firebase Auth
- **Property Listings**: Add, edit, and browse rental properties
- **Search & Filter**: Search by location, filter by rooms and price
- **Maps Integration**: Google Maps centered on Bhutan with property pins
- **Real-time Chat**: In-app messaging between users
- **Offline Support**: Room database for offline caching
- **Push Notifications**: FCM for new messages and listings
- **Bhutanese Identity**: Red theme with Dzongkhag (district) support

## Tech Stack

- **Language**: Kotlin
- **UI**: Jetpack Compose + Material3
- **Navigation**: Jetpack Navigation Component
- **Authentication**: Firebase Authentication
- **Database**: Firebase Firestore + Room (offline)
- **Image Loading**: Coil
- **Maps**: Google Maps SDK
- **Dependency Injection**: Hilt
- **Architecture**: MVVM + Repository pattern

## Project Structure

```
app/src/main/java/com/example/khangmate2/
├── data/
│   ├── model/          # Data models (User, Listing, Message, Dzongkhag)
│   ├── database/       # Room database setup
│   └── repository/     # Repository pattern implementation
├── navigation/         # Navigation setup
├── ui/
│   ├── components/     # Reusable UI components
│   ├── screens/        # App screens
│   └── theme/          # Material3 red theme
├── di/                 # Hilt dependency injection
└── MainActivity.kt
```

## Key Components

### UI Components
- `TopSearchBar`: Search input with rounded design
- `FilterChipsRow`: Horizontal filter chips
- `ListingCard`: Property listing card with image, price, and details
- `BottomNavBar`: 5-tab navigation with red highlight

### Screens
- **LoginScreen**: OTP authentication with Google/Facebook login
- **HomeScreen**: Property listings with search and filters
- **MapScreen**: Google Maps with property pins
- **ChatScreen**: Real-time messaging
- **ProfileScreen**: User profile and settings

### Data Models
- **User**: User profile with district (Dzongkhag)
- **Listing**: Property details with Ngultrum pricing
- **Message**: Chat messages with offline support
- **Dzongkhag**: 20 Bhutanese districts

## Setup Instructions

1. **Firebase Setup**:
   - Create a Firebase project
   - Enable Authentication, Firestore, Storage, and FCM
   - Add `google-services.json` to `app/` directory

2. **Google Maps**:
   - Get Google Maps API key
   - Add to `local.properties`:
     ```
     MAPS_API_KEY=your_api_key_here
     ```

3. **Build and Run**:
   ```bash
   ./gradlew assembleDebug
   ```

## Features in Detail

### Authentication
- Phone number OTP verification
- Google and Facebook sign-in
- User profile setup with district selection

### Property Management
- Add/edit/delete listings
- Upload multiple photos to Firebase Storage
- Price in Ngultrum (Nu.)
- District-based location system

### Search & Discovery
- Search by location or property name
- Filter by number of rooms
- Price range filtering
- Map view with property pins

### Messaging
- Real-time chat between users
- Offline message drafts
- Push notifications for new messages

### Offline Support
- Room database for local caching
- Offline drafts for listings and messages
- Sync when connection restored

## Bhutanese Integration

- **20 Dzongkhags**: All Bhutanese districts supported
- **Ngultrum Currency**: All prices displayed in Nu.
- **Red Theme**: Bhutanese identity colors
- **Local Focus**: Maps centered on Bhutan

## Future Enhancements

- [ ] Advanced search filters
- [ ] Property comparison
- [ ] Virtual tours
- [ ] Payment integration
- [ ] Multi-language support (Dzongkha)
- [ ] Property verification system

## Contributing

This is a full-featured Android app built for the Bhutanese rental property market. The codebase follows modern Android development practices with clean architecture and comprehensive offline support.

